from django.apps import AppConfig


class MebelConfig(AppConfig):
    name = 'mebel'
